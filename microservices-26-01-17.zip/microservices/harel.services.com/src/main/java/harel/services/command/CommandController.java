package harel.services.command;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import harel.services.domain.Offer;

@RestController
@RequestMapping("/command")
public class CommandController {
 
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public CommandController() {
		super();
		
	}
	
	@RequestMapping(method=RequestMethod.POST, path="/offer", produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Offer makeOffer(@RequestBody String dealId){
		logger.info("request received path {}/{}", "/command", "/offer");
		return new Offer(dealId);
	}
	

}
