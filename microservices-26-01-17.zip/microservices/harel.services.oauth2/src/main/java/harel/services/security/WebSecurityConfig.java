package harel.services.security;

import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.stereotype.Component;

import harel.services.security.jwt.JWTAuthenticationFilter;
import harel.services.security.jwt.JWTLoginFilter;

@Component
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	@Override
    protected void configure(HttpSecurity http) throws Exception {
        // disable caching
        http
        	.headers()
        	.cacheControl();

        http
        	.csrf()
        		.disable() // disable csrf for our requests.
            .authorizeRequests()
            	.antMatchers("/")
            		.permitAll()
            .antMatchers(HttpMethod.POST, "/login")
            	.permitAll()
        	.antMatchers(HttpMethod.GET, "/health")
            	.permitAll()
        	.antMatchers(HttpMethod.GET, "/metrics")
            	.permitAll()
        	.antMatchers(HttpMethod.GET, "/info")
            	.permitAll()
        	.antMatchers(HttpMethod.GET, "/env")
            	.permitAll()
        	.antMatchers(HttpMethod.GET, "/jolokia-endpoint")
            	.permitAll()
        	.antMatchers(HttpMethod.GET, "/dump")
            	.permitAll()
        	.antMatchers(HttpMethod.GET, "/trace")
            	.permitAll()
            	
            .anyRequest()
            	.authenticated()
            .and()
            	//We filter the /login requests
            	.addFilterBefore(new JWTLoginFilter("/login", authenticationManager()), UsernamePasswordAuthenticationFilter.class)
            	//And filter other requests to check the presence of JWT in header
            	.addFilterBefore(new JWTAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);
    }
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
	     // Create a default account
	     auth
	     	.inMemoryAuthentication()
	        .withUser("admin")
	        .password("admin")
	        .roles("ADMIN");
	     auth
	     	.inMemoryAuthentication()
	        .withUser("service")
	        .password("we_are_here_9_to_5")
	        .roles("SERVICE");
	}

}
