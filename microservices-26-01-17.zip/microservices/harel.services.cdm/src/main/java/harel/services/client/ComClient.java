package harel.services.client;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@FeignClient(name = "harel-services-com")
public interface ComClient {
	@RequestMapping(method = RequestMethod.POST, value = "/command/offer")
    String makeOffer(String dealId);
}

/*
@FeignClient(name = "harel-services-com")
public interface ComClient {
	@RequestMapping(method = RequestMethod.POST, value = "/command/offer")
	@HystrixCommand(fallbackMethod = "makeOfferDefault")
    String makeOffer(String dealId);
	
	public static String makeOfferDefault(String dealId) {
        return "-1";
    }
}
*/


