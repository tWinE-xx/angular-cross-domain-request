package harel.services.query;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

public class HystrixCommandQuery extends HystrixCommand<String> {

    private final String q;

    public HystrixCommandQuery(String q) {
        super(HystrixCommandGroupKey.Factory.asKey("harel.services.cdm.query"));
        this.q = q;
    }

    @Override
    protected String run() {
        return q;
    }
}