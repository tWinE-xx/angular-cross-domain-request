package harel.services.command;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import harel.services.client.ComClient;
import harel.services.domain.Offer;

@RestController
@RequestMapping("/command")
public class CommandController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private ComClient comClient;
    
    @Autowired
   	public CommandController(ComClient comClient) {
   		super();
   		this.comClient = comClient;
   	}
	
	@RequestMapping(method=RequestMethod.POST, path="/offer/{dealId}", produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	@HystrixCommand(fallbackMethod = "makeOfferFallback")
	public Offer makeOffer(@PathVariable String dealId){
		logger.info("request received path {}{}/:{}", "/command", "/offer", dealId);
		new HystrixCommandCommand(dealId).execute();
		//
		String offerId = this.comClient.makeOffer(dealId);
		//
		return new Offer(offerId);
	}
	
	public Offer makeOfferFallback(String dealId) {
        return new Offer("-1");
    }
}
