package harel.services.domain;

public class Deal {
	public String dealId;
	
	public Deal() {}
	
	public Deal(String dealId) {
		this.dealId = dealId;
	}
}
