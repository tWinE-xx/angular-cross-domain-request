var instance = null;
var Q = require('q');
var Worker = require('./worker.js');
var async = require('async');
var cpus = require('os').cpus().length;

function getInstance(){
    if (instance == null){
        instance = new TaskManager();
    }
    return instance;
}

function TaskManager(){
    this.tasks = [];
}

/**
 * Adds task to tasks array
 * @param  {string} command - command to execute
 * @param  {Array<string>} args - Arguments to the command.
 * @param  {string} cwd - The working directory to run the command in.
 * @return {GUID} taskId.
 * @example TaskManager.addTask("merge.js", __dirname, "1234");
 */
TaskManager.prototype.addTask = function(program, location, param){
    this.tasks.push({
        id: guid(),
        program: program,
        location: location,
        param: param
    });
    this.isRunning = false;
}

TaskManager.prototype.clearTasks = function(){
    this.tasks = [];
}

TaskManager.prototype.execute = function(cb){
    if (this.isRunning == true) {
        return cb("process already running");
    } else {
        this.isRunning = true;
        var jobs = [];
        this.tasks.forEach(task=>{
            jobs.push(task);
        });
        var execs = [];
        var i,j,chunckedJobs;
        for (i=0,j=jobs.length; i<j; i+=cpus) {
            chunckedJobs = jobs.slice(i,i+cpus);
            execs.push(executePartial.bind(this, chunckedJobs));
        }
        async.waterfall(
            execs,
            function(results) {
                this.isRunning = false;
                return cb(null, 1);
            }
        );
    }
}

function executePartial(jobs, callback){
    for(var i=0;i<jobs.length;i++)
        jobs[i] = Worker(jobs[i].id, "node", [jobs[i].program, jobs[i].param], jobs[i].location)
    Q
        .allSettled(jobs)
        .then((results) => {
            //remove tasks from queue
            results.forEach(result=>{
                if (result.state == 'fulfilled'){
                    this.tasks = this.tasks.filter(function(task) {
                        return task.id !== result.value;
                    });
                } else {
                    console.log("X could not execute taskId:", result.value);
                }
            });
            console.log("done");
            callback();
        });
}


module.exports = getInstance;

function guid() {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
    s4() + '-' + s4() + s4() + s4();
}