var instance = null;
var Q = require('q');
var Worker = require('./worker.js');
var async = require('async');
var cpus = require('os').cpus().length;

function getInstance(){
    if (instance == null){
        instance = new TaskManager();
    }
    return instance;
}

function TaskManager(){
    this.tasks = [];
}

/**
 * Adds task to tasks array
 * @param  {string} command - command to execute
 * @param  {Array<string>} args - Arguments to the command.
 * @param  {string} cwd - The working directory to run the command in.
 * @return {GUID} taskId.
 * @example TaskManager.addTask("merge.js", __dirname, "1234");
 */
TaskManager.prototype.addTask = function(program, location, param){
    this.tasks.push({
        id: guid(),
        program: program,
        location: location,
        param: param
    });
    this.isRunning = false;
}

TaskManager.prototype.clearTasks = function(){
    this.tasks = [];
}

TaskManager.prototype.execute = function(cb){
    if (this.isRunning == true) {
        return cb("process already running");
    } else {
        this.isRunning = true;
        var jobs = [];
        this.tasks.forEach(task=>{
            //jobs.push(Worker(task.id, "node", [task.program, task.param], task.location));
            jobs.push(task.id, "node", [task.program, task.param], task.location);
        });
        var jobOfJobs = [];
        var i,j,chunckedJobs;
        for (i=0,j=jobs.length; i<j; i+=cpus) {
            chunckedJobs = jobs.slice(i,i+cpus);
            jobOfJobs.push(chunckedJobs);
        }
        
        executeJobOfJobs(jobOfJobs, 0, jobOfJobs.length);
        
        
        /*
        */           
    }
}

function executeJobOfJobs(jobOfJobs, curr, total, cb){    
    if (curr>total){
        this.isRunning = false;
        return cb(null, 1);
    } else {
        for (var i=0;i<jobOfJobs[curr];i++)

        Worker( 
        );
        Q
            .allSettled(jobOfJobs[curr])
            .then((results) => {
                console.log('!!!!sss', result[0])
                curr ++;
                //remove tasks from queue
                results.forEach(result=>{
                    this.tasks = this.tasks.filter(function(task) {
                        return task.id !== result.value;
                    });
                });
                executeJobOfJobs(jobOfJobs, curr, total, cb);
            });
    }

}

function executePartial(jobs, callback){
    Q
        .allSettled(jobs)
        .then((results) => {
            //remove tasks from queue
            results.forEach(result=>{
                this.tasks = this.tasks.filter(function(task) {
                    return task.id !== result.value;
                });
            });
            callback(null, results);
        });
}


module.exports = getInstance;

function guid() {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
    s4() + '-' + s4() + s4() + s4();
}