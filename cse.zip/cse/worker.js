var spawn = require("child_process").spawn;
var Q = require("q");

/**
 * Wrap executing a command in a promise
 * @param  {string} command command to execute
 * @param  {Array<string>} args    Arguments to the command.
 * @param  {string} cwd     The working directory to run the command in.
 * @return {Promise}        A promise for the completion of the command.
 */
module.exports = function exec(takId, command, args, cwd) {
    if (!command || !cwd) {
        return Q.reject(takId, new Error("Both command and working directory must be given, not " + command + " and " + cwd));
    }

    var deferred = Q.defer();

    console.log("+", command, args.join(" "), "# in", cwd);

    var proc = spawn(command, args, {
        cwd: cwd,
        stdio: "inherit"
    });
    proc.on("error", function (error) {
        deferred.reject(takId, new Error(command + " " + args.join(" ") + " in " + cwd + " encountered error " + error.message));
    });
    proc.on("exit", function(code) {
        if (code !== 0) {
            deferred.reject(takId, new Error(command + " " + args.join(" ") + " in " + cwd + " exited with code " + code));
        } else {
            console.log("-", takId);
            deferred.resolve(takId);
        }
    });
    return deferred.promise;
};