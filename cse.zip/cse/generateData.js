//require node modules (see package.json)
var MongoClient = require('mongodb').MongoClient
    , format = require('util').format;

//connect away
MongoClient.connect('mongodb://127.0.0.1:27017/se', function(err, db) {
    if (err) throw err;
    console.log("Connected to Database");
    
    for (var i=0;i<10*1000;i++){
        //simple json record
        var me = this;
        var offerIdddd = Math.floor(Math.random() * 100000) + 1;
        //insert record
        for (var j=0;j<5;j++){
            db.collection('treatments').insert(createDoc(Math.floor(Math.random() * 1000000000) + 1, offerIdddd), insertCb.call(me));
        }

        function insertCb(err, records) {
            if (err) console.log(err);
            console.log("Record added" + new Date().toTimeString());
        }        
    }
});

function createDoc(id, offerId){
    return {
            campaignCd: "campaignCd="+Math.floor(Math.random() * 200) + 1,
            offerID: offerId  ,
            policyID: Math.floor(Math.random() * 100000) + 1,
            insuredFamilyRelationKod: "insuredFamilyRelationKod",
            insuredFamilyRelationDesc: "insuredFamilyRelationDesc",
            insuredZehutKod: Math.floor(Math.random() * 3) + 1,
            insuredZehut: id,
            insuredFirstName: "insuredFirstName"+Math.floor(Math.random() * 1000) + 1,
            insuredLastName:  "insuredLastName"+Math.floor(Math.random() * 1000) + 1,
            insuredBirthdate: "insuredBirthdate",
            insuredAge: "insuredAge",
            insuredMinKod: "insuredMinKod",
            insuredMinDesc: "insuredMinDesc",
            ishunIndKod: "ishunIndKod",
            ishunIndTeur: "ishunIndTeur",
            insuredPhonePrefix: "insuredPhonePrefix",
            insuredPhoneSuffix: "insuredPhoneSuffix",
            insuredOtherPhonePrefix: "insuredOtherPhonePrefix",
            insuredOtherPhoneNumber: "insuredOtherPhoneNumber",
            insuredEmail: "insuredEmail",
            insuredCity: "insuredCity",
            insuredStreet: "insuredStreet",
            insuredHomeNumber: "insuredHomeNumber",
            insuredZip: "insuredZip",
            agentNumber: "agentNumber",
            agentName: "agentName",
            agentLicense: "agentLicense",
            agentPhonePrefix: "agentPhonePrefix",
            agentPhoneSuffix: "agentPhoneSuffix",
            agentOtherPhonePrefix: "agentOtherPhonePrefix",
            agentOtherPhoneSuffix: "agentOtherPhoneSuffix",
            agentEmail: "agentEmail",
            agentInspectorName: "agentInspectorName",
            agentShimurGroup: "agentShimurGroup",
            agentPhoneSellerInd: "agentPhoneSellerInd",
            anafKod: "anafKod",
            anafDesc: "anafDesc",
            gviyaID: "",
            gviyaDesc: "",
            gviya4Digits: "",
            validDate: "",
            shumbthCurrent: "",
            shumbthNew1: "",
            shumbthNew2: "",
            premiaCurrent: "",
            insuredMaxNumOfPackages: "",
            premiaNew1: "",
            premiaNew2: "",
            premiaNew3: "",
            Hanacha: "",
            Tosefet1: "",
            Tosefet2: "",
            Tosefet3: "",
            Tosefet4: "",
            Tosefet5: "",
            question1: "",
            question2: "",
            question3: ""
        }
}