var MongoClient = require('mongodb').MongoClient;

var offerId;
try {
    offerId = parseInt(process.argv[2]);
} catch (e) {
    return process.exit("oculd not convert offerId to int", offerId, e);
}

MongoClient.connect('mongodb://127.0.0.1:27017/se', function(err, db) {
    if (err) return process.exit(err);
    db.collection('treatments').find({"offerID": offerId}).toArray((err, offersById)=>{
        if (err) return process.exit(err);
        db.collection('joined').insert({offerId:offerId, treatments: offersById}, (err, insertResult)=>{
            if (err) return process.exit(err);
            db.close();
            return process.exit(0);
        });
    });
});