var MongoClient = require('mongodb').MongoClient;
var TaskManager = require('./manager')();

MongoClient.connect('mongodb://127.0.0.1:27017/se', function(err, db) {
    if (err) throw err;
    //distinct by offerID
    db.collection('treatments').distinct("offerID", distinctCallback.bind(db));
});

function distinctCallback(err, offerIds){
    var db = this;
    if (err) throw err;
    var startDate = new Date();
    var jobs = [];
    //offerIds.splice(6);
    offerIds.forEach(offerId=>{
        TaskManager.addTask("merge.js", __dirname, offerId);
    })
    TaskManager.execute((err, result)=>{
       console.log(offerIds.length, 'offers', 'delta', (new Date().getTime() - startDate.getTime()) / 1000);
        db.close();
    });
}
