package harel.services.query;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/query")
public class QueryController {
 
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public QueryController() {
		super();
		
	}
	
	@RequestMapping(method=RequestMethod.GET, path="/", produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public List<String> query(@RequestParam String q){
		logger.info("request received path {}/{}, q={}", "query", "", q);
		return Arrays.asList("1", "2");
	}
	

}
