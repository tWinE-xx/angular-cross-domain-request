package harel.services.command;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

public class HystrixCommandCommand extends HystrixCommand<String> {

    private final String dealId;

    public HystrixCommandCommand(String dealId) {
        super(HystrixCommandGroupKey.Factory.asKey("harel.services.cdm.makeOffer"));
        this.dealId = dealId;
    }

    @Override
    protected String run() {
        return dealId;
    }
}