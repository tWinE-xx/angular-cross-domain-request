package harel.services.domain;

public class Offer {
	public String offerId;
	
	public Offer() {}
	
	public Offer(String offerId) {
		this.offerId = offerId;
	}
}
